'''
Author: Grace Edwin
M.Sc. Cyber Security (Semester: IV)
Amity University, Rajasthan

Securin Assignment
'''

#imports
import math
from collections import defaultdict

#1. Total possible combination:
def total_combination(A,B):
    a=len(A)
    b=len(B)
    return a*b

#2. Calculate and display the distribution of all possible combinations:
def distribution(A,B):
    combinations=[]
    for i in A:
        temp=[]
        for j in B:
            a=(i,j)
            temp.append(a)
        combinations.append(temp)
    return combinations

#3. Calculate the Probability of all Possible Sums occurring among the number of combinations from (2).
def probabilities(A,B):
    dist=distribution(A, B)
    probability = defaultdict(int)
    for row in dist:
        for i, j in row:
            sum_val = i + j
            #print("Sum val:  ",sum_val)
            probability[sum_val] += 1
            #print(sum(probability.values()))
    total_comb = sum(probability.values())
    for key in probability:
        probability[key] /= total_comb
    #print(probability.values())
    return probability

# 4. Undoom the Dice
def undoom_dice(A, B):
    original_probabilities = probabilities(A, B)
    newDieA = [0] * 6  # Initialize newDieA as a list of zeros
    newDieB=B
    # Iterate over each face of Die A
    for i in range(6):
        new_probabilities = sum(original_probabilities[sum_val] for sum_val in range(2, 13) if sum_val - i in range(6))
        # Calculate the spots on Die A, ensuring it doesn't exceed 4
        newDieA[i] = min(4, int(round(new_probabilities * 36 / 6)))
        
    #print(newDieA, newDieB)
    newDieB = [1, 2, 3, 4, 5, 6]  # Die B remains unchanged
    return newDieA, newDieB
            



#constant (Inputs)
dieA=[1,2,3,4,5,6]
dieB=[1,2,3,4,5,6]
newDieA=[0]*6
newDieB=[0]*6

#Outputs (Display)

#1. How many total combinations are possible?
print("\n1. How many total combinations are possible?\n")
print("\tThe total combination can be calculated by multiplying the number of faces on each (die i.e Die A and Die B). \n")
print("\t.'. the total combination = (no. of faces on die A) * (no. of faces on die B)\n")
print("\t.'. the total combination = ", total_combination(dieA,dieB))

#2. Calculate and display the distribution of all possible combinations that can be obtained when rolling both Die A and Die B together

print("\n2. Calculate and display the distribution of all possible combinations: \n")
print("\tTo calculate the distribution of all possible combinations, we create a matrix.\n")
print("\tHere, each cell in row represents the result of rolling the Die A and Die B once.\n")
print("\t'.' Both dices have equal number of face, the matrix will be [n*n]\n")
print("\t.'. the distribution will be as follows: \n")
for i in range(len(dieA)):
    print("\t\t", distribution(dieA,dieB)[i])

#3. Calculate the Probability of all Possible Sums occurring among the number of combinations from (2).
print("\n3. Calculate the Probability of all Possible Sums occurring among the number of combinations from (2)\n")
print("\tTo calculate the probability of all possible sums:")
print("\t\t Step 1: Counted the occurrences of each sum in the distribution of combinations obtained in Question 2.,")
print("\t\t Step 2: Divided each occurence by the total number of combinations (36).,")
print("\t.'. the the Probability of all Possible Sums = (no. fo occurence of each sum)/the total combination")
print("\t.'. Probability of all possible sums is as follows: ")
list_prob=list(probabilities(dieA,dieB).values())
for i in range(2,13):
    print("\t\tP(Sum=",i,")="," %.2f" % list_prob[i-2])

"""iterate through all possible configurations of Die A and check if the probability distribution of sums remains the same"""
#4. Undoom the dices.
print("\n4. Undoom the dices\n")
print("\tTo undoom the dices such that it satisies all conditions, following steps can be taken:")
print("\t\t Step 1: Calculation of the original probabilities [from Question 3] ")
print("\t\t Step 2: Positioning of Die A [?,?,?,?,?,?]")
print("\t\t > Determine the necessary total probability for each face of Die A such that the chances of achieving each sum stay the same.")
print("\t\t > We keep the values of Die B faces the same as original. ('.' it satisfies the condition.)")
print("\t\t > Ensure that the overall probability for each face does not exceed 4, \n\t\tas stated in the challenge. Set the amount of spots on each face accordingly.")
print("\t\t Step 3: Determine the New Die A")
print("\t\t > Using the new probability, determine how many places are required for each face.")
print("\t\t > Make sure (calculated no. of spots on dieA < 4) and assign a determined number of spots on each face of Die A.")
print("\t.'. The newly undoomed dices are as follows: \n\t\tNew Die A =", undoom_dice(dieA, dieB)[0],"\n\t\tNew Die A =", undoom_dice(dieA, dieB)[1])



